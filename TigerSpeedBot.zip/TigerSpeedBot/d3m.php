<?php

// Constants
$adminId = 6506780205; // Admin ID
$apiUrl = "https://api.telegram.org/bot" . $botToken; // Replace $botToken with your bot token

// Functions
function bot($method, $data = []) {
    global $apiUrl;
    $url = $apiUrl . "/" . $method;
    $options = [
        'http' => [
            'header'  => "Content-Type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($data),
        ],
    ];
    $context  = stream_context_create($options);
    return json_decode(file_get_contents($url, false, $context));
}

// Handle Updates
$update = json_decode(file_get_contents('php://input'), true);

if (isset($update['callback_query'])) {
    $data = $update['callback_query']['data'];
    $chatId = $update['callback_query']['message']['chat']['id'];
    $messageId = $update['callback_query']['message']['message_id'];
    $userId = $update['callback_query']['from']['id'];
    $firstName = $update['callback_query']['from']['first_name'];
    $username = $update['callback_query']['from']['username'];
}

if (isset($update['message'])) {
    $message = $update['message'];
    $chatId = $message['chat']['id'];
    $messageId = $message['message_id'];
    $text = $message['text'] ?? '';
    $photoId = $message['photo'][0]['file_id'] ?? '';
    $videoId = $message['video']['file_id'] ?? '';
    $stickerId = $message['sticker']['file_id'] ?? '';
    $documentId = $message['document']['file_id'] ?? '';
    $audioId = $message['audio']['file_id'] ?? '';
    $voiceId = $message['voice']['file_id'] ?? '';
    $caption = $message['caption'] ?? '';
    $replyToMessage = $message['reply_to_message'] ?? null;
    $replyToMessageId = $replyToMessage['message_id'] ?? null;
    $replyToUserId = $replyToMessage['from']['id'] ?? null;
    $chatType = $message['chat']['type'];
}

// Load or Initialize Data
$phpxx = json_decode(file_get_contents("PHPXX.json"), true) ?? [];

// Handle Commands and Callbacks
if ($text === "/start") {
    unlink("data/id/$userId/step.txt");
    unlink("data/id/$userId/twas.txt");
    exit;
}

if ($data === "TWASL") {
    bot('EditMessageText', [
        'chat_id' => $chatId,
        'message_id' => $messageId,
        'text' => "💬 *- قسم التواصل مع الدعم أونلاين*\n\n⚜ - هنا يمكنك *التواصل معنا* لحل جميع *المشكلات التي قد تواجهك* في البوت. 💛\n☑️ - أرسل *رسالتك* الآن وسوف يتم *إيصالها الى الإدارة* مباشرة.\n🕰 - متواجدون طوال اليوم. ❄️\n❎ - لاترسل الألفاظ البذيئة فضلا. ☺️🖤",
        'parse_mode' => "MarkDown",
        'reply_markup' => json_encode(['inline_keyboard' => [['text' => "- الغاء التواصل ⛔️", 'callback_data' => "back"]]])
    ]);
    file_put_contents("data/id/$userId/twas.txt", "tw");
    file_put_contents("PHPXX.json", json_encode($phpxx));
}

if ($data === "back") {
    unlink("data/id/$userId/step.txt");
    unlink("data/id/$userId/twas.txt");
    exit;
}

if ($chatType === "private" && $text && $chatId !== $adminId && isset($phpxx['tws'])) {
    if ($text !== "/start" && $phpxx['tws'][$messageId] !== null) {
        $forwardMessage = bot('forwardMessage', [
            'chat_id' => $adminId,
            'from_chat_id' => $chatId,
            'message_id' => $messageId,
        ]);
        $forwardMessageId = $forwardMessage->result->message_id;
        $phpxx['tws'][$forwardMessageId]['User'] = $chatId;
        $phpxx['tws'][$forwardMessageId]['Message'] = $messageId;
        file_put_contents("PHPXX.json", json_encode($phpxx));
        bot('sendMessage', [
            'chat_id' => $chatId,
            'text' => "☑️ *- تم إرسال رسالتك للمدير بنجاح*\n♻️ - الرجاء التحلي بالصبر ريثما يتم الرد عليك* 🤙🏻",
            'parse_mode' => "MarkDown",
            'reply_to_message_id' => $messageId,
            'reply_markup' => json_encode(['inline_keyboard' => [['text' => "- الغاء التواصل ⛔️", 'callback_data' => "back"]]])
        ]);
    }
}

if ($chatId === $adminId && isset($phpxx['tws'][$messageId]) && $replyToMessageId) {
    $originalMessageId = $phpxx['tws'][$messageId]['Message'];
    $originalUserId = $phpxx['tws'][$messageId]['User'];
    $responseMessage = "";

    if ($text) {
        bot('sendMessage', [
            'chat_id' => $originalUserId,
            'text' => "$responseMessage$text",
            'reply_to_message_id' => $originalMessageId,
        ]);
    } elseif ($photoId) {
        bot('sendPhoto', [
            'chat_id' => $originalUserId,
            'photo' => $photoId,
            'caption' => $responseMessage . $caption,
            'reply_to_message_id' => $originalMessageId,
        ]);
    } elseif ($videoId) {
        bot('sendVideo', [
            'chat_id' => $originalUserId,
            'video' => $videoId,
            'caption' => $responseMessage . $caption,
            'reply_to_message_id' => $originalMessageId,
        ]);
    } elseif ($stickerId) {
        bot('sendSticker', [
            'chat_id' => $originalUserId,
            'sticker' => $stickerId,
            'reply_to_message_id' => $originalMessageId,
        ]);
    } elseif ($documentId) {
        bot('sendDocument', [
            'chat_id' => $originalUserId,
            'document' => $documentId,
            'caption' => $responseMessage . $caption,
            'reply_to_message_id' => $originalMessageId,
        ]);
    } elseif ($audioId) {
        bot('sendAudio', [
            'chat_id' => $originalUserId,
            'audio' => $audioId,
            'caption' => $responseMessage . $caption,
            'reply_to_message_id' => $originalMessageId,
        ]);
    } elseif ($voiceId) {
        bot('sendVoice', [
            'chat_id' => $originalUserId,
            'voice' => $voiceId,
            'caption' => $responseMessage . $caption,
            'reply_to_message_id' => $originalMessageId,
        ]);
    }

    bot('sendMessage', [
        'chat_id' => $chatId,
        'text' => "☑️ *- تم الرد على المستخدم بنجاح* 🤙🏻",
        'parse_mode' => "MarkDown",
        'reply_to_message_id' => $messageId,
        'reply_markup' => json_encode(['inline_keyboard' => [['text' => "☑️ - رابط العضو ↖️", 'url' => "tg://openmessage?user_id=$originalUserId"]]])
    ]);
}
?>