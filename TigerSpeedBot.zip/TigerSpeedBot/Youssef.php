<?php
$arab = ["YE", "SY", "IQ", "EG", "SA", "AE", "JO", "LB", "DZ", "MA", "TN", "LY", "SD", "MR", "KM", "DJ", "SO", "SS", "KW", "BH", "QA", "OM"];
$europ = ['AL', 'AD', 'AT', 'BY', 'BE', 'BA', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EU', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IS', 'IE', 'IT', 'LV', 'LI', 'LT', 'LU', 'MT', 'MD', 'MC', 'ME', 'NL', 'MK', 'NO', 'PL', 'PT', 'RO', 'SM', 'RS', 'SK', 'ES', 'SI', 'SE', 'CH', 'UA', 'GB'];
$json_country = json_decode(file_get_contents('data/country.json'), true);
$get_country_name = json_decode(file_get_contents('data/country.json'));
if ($data == 'TgYoussef') {
    bot('editMessageText', [
        'chat_id' => $chat_id2,
        'message_id' => $message_id2,
        'text' => "
*👤︙مرحباً بك* [$first_name](tg://user?id=$id) 🖤.

🪗︙أنت *الآن* في *[📱 ⪼ قسم الأرقام.]*
🌐︙قم *بإختيار* القسم الذي *تريده* من *الأسفل* ⬇️.

-",
        'parse_mode' => "MarkDown",
        'reply_markup' => json_encode([
            'inline_keyboard' => $tg_buttons
        ])
    ]);
}

if ($exdata[0] == 'NewNumberr') {
    $my_choice = $exdata[1];
    $all_countries_raw = file_get_contents($API_NUMBER . 'action=services');
    $all_countries = json_decode($all_countries_raw);

    // تأكد من الطباعة للتحقق من البيانات
    error_log("API Response: " . $all_countries_raw);

    // تعديل الرسالة لعرض رسالة جلب الدول المتوفرة
    bot('editMessageText', [
        'chat_id' => $chat_id2,
        'message_id' => $message_id2,
        'text' => "✅ ⌯ يتم جلب الدول المتوفرة..",
        'reply_markup' => json_encode([
            'inline_keyboard' => []
        ])
    ]);

    if ($all_countries && $all_countries->ok) {
        $all_countries_array = $all_countries->data;
        $buttons_c = [];
        $description = '';

        // الحصول على معلومات العملة من قاعدة البيانات
        include('sql_class.php');
        $sqsq = $sql->sql_select('users', 'user', $id2);
        $mycoin = $sqsq['mycoin'];
        $info_coin = get_coin_info($mycoin);
        $coin_name = $info_coin[1];
        $coin_rate = $info_coin[0];

        // تأكد من الطباعة للتحقق من القيم
        error_log("User Coin Info: " . print_r($info_coin, true));

        // تحديد وصف القسم بناءً على $my_choice
        if ($my_choice == 'ar') {
            $description = "🌐︙الدول العربية.";
            $filter = $arab;
        } elseif ($my_choice == 'er') {
            $description = "🌐︙الدول الأوروبية.";
            $filter = $europ;
        } elseif ($my_choice == 'ot') {
            $description = "🌐︙جميع الدول.";
            $filter = array_diff(array_keys($all_countries_array), array_merge($arab, $europ));
        }

        foreach ($all_countries_array as $key => $value) {
            if (($my_choice == 'ot' && !in_array($key, $arab) && !in_array($key, $europ)) || ($my_choice != 'ot' && in_array($key, $filter))) {
                // حساب السعر مع تضمين نسبة الربح وتحويل العملة
                $rate = $value->price;
                $prec_c = $config->Profit;
                $price = ((($rate / 100) * $prec_c) + $rate) * $coin_rate;

                // تأكد من الطباعة للتحقق من الأسعار
                error_log("Country: $key, Rate: $rate, Price: $price");

                $cty = $value->ar . " " . $value->flag;

                // إضافة زرين لكل دولة: الأول لاسم الدولة، الثاني للسعر
                $buttons_c[] = [
                    ['text' => $cty, 'callback_data' => "GetNumber|$key|$price"],
                    ['text' => $price . " " . $coin_name, 'callback_data' => "GetNumber|$key|$price"]
                ];
            }
        }

        // إضافة زر الرجوع
        if (count($buttons_c) > 0) {
            $buttons_c[] = [['text' => '🔙︙رجوع.', 'callback_data' => 'TgYoussef']];
            bot('editMessageText', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "
*👤︙مرحباً بك* [$first_name](tg://user?id=$id) 🖤.

☑️︙أنت *الآن* في قسم *[ $description ]،*
*🌐︙قم بإختيار الدولة التي تريدها من الأسفل 👇🏻.*

-",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $buttons_c
                ])
            ]);
        } else {
            // إذا لم يكن هناك أي دول لعرضها
            bot('editMessageText', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "❌ لا توجد دول متاحة في هذا القسم.",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [['text' => '🔙︙رجوع.', 'callback_data' => 'TgYoussef']]
                ])
            ]);
        }
    } else {
        error_log("API Response Error or Not OK: " . print_r($all_countries, true));
    }
}
include ('mtofer.php');