<?php
$TG_KEY = '370bfd0a-a35b-4929-a4d1-0d420b5bef26'; # خذ المفتاح من الرابط https://tg-accounts.com/API
$API_NUMBER = "https://tg-accounts.com/API/v1/number?token=$TG_KEY&"; # لا تلمس شي
$arab = ["YE", "SY", "IQ", "EG", "SA", "AE", "JO", "LB", "DZ", "MA", "TN", "LY", "SD", "MR", "KM", "DJ", "SO", "SS", "KW", "BH", "QA", "OM"];
$europ = ['AL', 'AD', 'AT', 'BY', 'BE', 'BA', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EU', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IS', 'IE', 'IT', 'LV', 'LI', 'LT', 'LU', 'MT', 'MD', 'MC', 'ME', 'NL', 'MK', 'NO', 'PL', 'PT', 'RO', 'SM', 'RS', 'SK', 'ES', 'SI', 'SE', 'CH', 'UA', 'GB'];
$json_country = json_decode(file_get_contents('data/country.json'), true);
$get_country_name = json_decode(file_get_contents('data/country.json'));
$MyYoussef = [
[['text' => "🪗︙تسجيل خروج للخادم", 'callback_data' => "LogOut|".$number]],
];
$tg_buttons = [
    [['text' => "🌐︙شراء رقم عربي.", 'callback_data' => "NewNumberr|ar"]],
    [['text' => "🌐︙شراء رقم أوروبي.", 'callback_data' => "NewNumberr|er"]], 
    [['text' => "🌐︙دول أخرى", 'callback_data' => "NewNumberr|ot"]],
    [['text' => "🔙︙إلغاء ورجوع", 'callback_data' => "back2"]],
];
$Youssef = [ 
    [['text' => "☑️︙بدء الإستخدام", 'callback_data' => "home"]],
    [['text' => "🔏︙الشروط و الخصوصية.", 'callback_data' => "help"]],
    [['text'=> "👨🏻‍🔧︙طلب الدعم.", 'url'=> "tg://user?id=".$aldorafy]],
];
if($text == '/start') {
bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "*👤︙مرحباً بك* [$first_name](tg://user?id=$id) 🖤.

🤖︙بوت *تـايـجـر سـبـيـد* - *$NameBotG* 🤖. هو بوت *مختص* *بتقديم* الخدمات *الرائجة* في مواقع *التواصل الإجتماعي* ⭐.

*🚀 ⌯ اضغط على زر بدء الإستخدام للدخول. 👇🏻.*",
 'parse_mode' => "MarkDown",
            'disable_web_page_preview' => true,
            'reply_markup' => json_encode([
                'inline_keyboard' => $Youssef
            ])
        ]);
        return;
    }

if($data == 'home'){
    
    $jsons["$id2"] = null;
        file_put_contents("data/data.json", json_encode($jsons));
        include('./sql_class.php');
        $sq = $sql->sql_select('users', 'user', $id2);
        $coin = $sq['coin'];
        $mycoin = $sq['mycoin'];
        $info_coin = get_coin_info($mycoin);
        $coin_after_coin = $info_coin[0] * $coin;
        $coin_name = $info_coin[1];
        bot('editmessagetext', [
            'chat_id' => $chat_id2,
            'message_id' => $message_id2,
            'text' => "*👤︙مرحباً بك* [$first_name](tg://user?id=$id) 🖤.

🤖︙بوت *تـايـجر سـبـيـد* - *$NameBotG* 🤖. هو بوت *مختص* بتقديم الخدمات *الرائجة* في مواقع *التواصل الإجتماعي* ⭐.

*☑️︙حسابك :*`$id2`.
*💳︙رصيدك : $coin_after_coin $coin_name.*
*🪙︙العملة : $coin_name.*

🙋🏻︙يمكنك *التحكم بالبوت* عبر الأزرار في *الاسفل ⬇️.*",
'parse_mode'=>"MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => $start
            ])
        ]);
    }
            if($data == 'TWASLL'){
        bot('editmessagetext', [
            'chat_id' => $chat_id2,
            'message_id' => $message_id2,
            'text' => "*👤︙مرحباً بك عزيزي* [$first_name](tg://user?id=$id) 🖤.
            
*✅︙أنت الآن في تواصل مباشر مع إدارة البوت.!*
*🪗︙أي شيء تكتبه الآن سيتم إرساله للإدارة مباشرة 🚀.*

*⚠️︙فضلاً إبتعد عن الألفاظ البذيئة التي قد تؤدي إلى حظر حسابك مباشرة.*

*🔗︙أرسل رسالتك الآن وإنتظر حتى تقوم الإدارة بالرد عليك 👇🏼.*",
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => $back2
            ])
        ]);
    }
// إعداد معلومات البوت
        if($data == 'tg_buttons'){
        bot('editmessagetext', [
            'chat_id' => $chat_id2,
            'message_id' => $message_id2,
            'text' => "
*👤︙مرحباً بك* [$first_name](tg://user?id=$id) 🖤.

🪗︙أنت *الآن* في *[📱 ⪼ قسم الأرقام.]*
🌐︙قم *بإختيار* القسم الذي *تريده* من *الأسفل* ⬇️.

-
            ",
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => $tg_buttons
            ])
        ]);
    }
    
    if($exdata[0] == 'NewNumber'){
        $my_choice = $exdata[1];
        $all_countries  = json_decode(file_get_contents($API_NUMBER.'action=services'));
        if($all_countries->ok){
            bot('answerCallbackQuery',[
                'callback_query_id'=>$update->callback_query->id,
                'text'=>"✅ ⌯ يتم جلب الدول المتوفرة..", 
                'show_alert'=>true,
                'cache_time'=> 10
            ]);
$all_countries_array = $all_countries->data;
$buttons_c = [];
$double = [];
        $description = '';
        
          include ('sql_class.php');
        $sqsq = $sql->sql_select('users', 'user', $id2);
        $mycoin = $sqsq['mycoin'];
        $info_coin = get_coin_info($mycoin);
        $coin_name = $info_coin[1];
        $coin_rate = $info_coin[0];
        
        // تحديد وصف القسم بناءً على $my_choice
        if ($my_choice == 'ar') {
            $description = "🌐︙الدول العربية.";
            $filter = $arab;
        } elseif ($my_choice == 'er') {
            $description = "🌐︙الدول الأوروبية.";
            $filter = $europ;
        } elseif ($my_choice == 'ot') {
            $description = "🌐︙جميع الدول.";
            $filter = array_diff(array_keys($all_countries_array), array_merge($arab, $europ));
        }
foreach($all_countries_array as $key => $value){
/*
    if($my_choice == 'ar'){
        if(!in_array($key, $arab)){
            continue;
        }
    }
    if($my_choice == 'er'){
        if(!in_array($key, $europ)){
            continue;
        }
    }
    if($my_choice == 'ot'){
        if(in_array($key, $europ) or in_array($key, $arab)){
            continue;
        }
    }
*/
    // حساب السعر مع تضمين نسبة الربح وتحويل العملة
                $rate = $value->price;
                $prec_c = $config->Profit;
                $price = ((($rate / 100) * $prec_c) + $rate);
    $cty = $value->ar." ".$value->flag;
    $json_country[$key] = $cty;
    
    $double[] = ['text' => "$cty ⏎ $price$", 'callback_data' => "GetNumber|$key|$price"];
    if(count($double) == 2){
        $buttons_c[] = $double;
        $double = [];
    }

// الكود المتبقي لإرسال الأزرار أو معالجتها
                if(count($buttons_c) > 48){
                    bot('sendMessage', [
                        'chat_id' => $chat_id2,
                        'text' => "✅︙بعد الضغط على الدولة سوف يتم شراء رقم لك مباشرة ولايمكنك التراجع مهما حصل 📱.
🔏︙الآن قم بإختيار الدولة المراد شراء رقم لها من الأسفل ♠️.",
                        'reply_markup' => json_encode([
                            'inline_keyboard' => $buttons_c,$back2
                        ])
                    ]);
                    $buttons_c = [];
                }
            }
            if(count($buttons_c) != 0){
                bot('sendMessage', [
                    'chat_id' => $chat_id2,
                    'text' => "✅︙بعد الضغط على الدولة سوف يتم شراء رقم لك مباشرة ولايمكنك التراجع مهما حصل 📱.
🔏︙الآن قم بإختيار الدولة المراد شراء رقم لها من الأسفل ♠️.",
                    'reply_markup' => json_encode([
                        'inline_keyboard' => $buttons_c,$back2
                    ])
                ]);
            }
            file_put_contents("data/country.json", json_encode($json_country));

        }else{
            bot('answerCallbackQuery',[
                'callback_query_id'=>$update->callback_query->id,
                'text'=>"🤖 ⌯ حصل خطأ، حاول مجددا بعد قليل.!", 
                'show_alert'=>true,
                'cache_time'=> 10
            ]);
        }

    }
    if($exdata[0] == 'GetNumber'){
        $country = $exdata[1];
        $price = $exdata[2];
        include('./sql_class.php');
        if (mysqli_connect_errno()) {
            return;
        }
        $sq = $sql->sql_select('users', 'user', $id2);
        $coin = $sq['coin'];
        $spent = $sq['spent'];
        if($coin < $price){
            bot('sendmessage',[
                'chat_id' => $chat_id2,
                'text' => "
*❌︙رصيدك غير كافي للشراء..*
*☑️︙قم بإعادة شحن حسابك!!*", 
'parse_mode' => "MarkDown",
            ]);
            return;
        }
        $mm = $sql->sql_readarray_count('order_waiting') + $sql->sql_readarray_count('order_done');
$Aymmmm = $mm + 1;
$Aymmm  = $mm + 1;
$Aymm  = $mm + 1;
$Aym  = $mm + 1;
        bot('answerCallbackQuery',[
            'callback_query_id'=>$update->callback_query->id,
            'text'=>"✅︙يتم شراء الرقم لك..", 
            'show_alert'=>true,
            'cache_time'=> 10
        ]);
        $coin_after = $coin - $price;
        $spent_after = $spent + $price;
        $sql->sql_edit('users', 'coin', $coin_after, 'user', $id2);
        #$buy_number = json_decode(file_get_contents($API_NUMBER.'action=number&service='.$country));
        $buy_number = json_decode(file_get_contents($API_NUMBER.'action=number&service='.$country));
        if($buy_number->ok){
            $new_number = $buy_number->data->number;
            $name_country = $get_country_name->{$country};
            $cap = "
🎬︙التطبيق : *تيليجرام.*
*🧿︙رقم الطلب* :  *$Aymmm*

*☎️︙الرقم* : `$new_number`
*🌐︙الدولة : $name_country*.
*💸︙السعر* : $price $coin_name";

            $cap_for_ch = "
🎬︙التطبيق : *تيليجرام.*
🧿︙رقم الطلب : *$Aymmm*.

*📱︙الرقم* : ".substr_replace($new_number, '××××', -4)."
*🌐︙الدولة : $name_country*.
*💸︙السعر: $price $coin_name*
";

            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "
*✅︙تم شراء رقم بنجاح .*

$cap

*🔗︙يرجى تسجيل الرقم في تيليجرام ، بعد التسجيل ، إضغط على ( ✅︙طلب الكود  ) للحصول على كود التفعيل*.
                ",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [['text' => "✅︙طلب الكود", 'callback_data' => "GetCode|".$new_number]],
                    ]
                ])
            ]);

            bot('sendmessage', [
                'chat_id' => $dev,
                'text' => "
*✅︙عملية شراء رقم جديدة.*

$cap

*🆔︙الزبون : `$id2`*.

💲︙رصيده قبل الشراء : $coin $coin_name
💸︙رصيده بعد الشراء : $coin_after $coin_name
💳︙رصيده المصروف : $spent_after $coin_name

                ",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $my_bot
                ])
            ]);

            bot('sendmessage', [
                'chat_id' => $IDCH,
                'text' => "
*✅︙عملية شراء رقم جديدة.*

$cap_for_ch

*🆔︙العميل : *".substr_replace($id2, '×××', -3)."
                ",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $my_bot
                ])
            ]);


            $spent_after = $spent + $price;
            $sql->sql_write('number_done(user,type,caption)', "VALUES('$id2','telegram','$cap')");
            $sql->sql_edit('users', 'spent', $spent_after, 'user', $id2);
        }else{
            $sql->sql_edit('users', 'coin', $coin, 'user', $id2);
            bot('sendmessage',[
                'chat_id' => $chat_id2,
                'text' => "*🤖︙حصل خطأ ما، حاول مجددا بعد قليل..❌*", 
                'parse_mode' => "MarkDown",
            ]);
        }

    }


    if($exdata[0] == 'GetCode'){
        bot('answerCallbackQuery',[
            'callback_query_id'=>$update->callback_query->id,
            'text'=>'✅︙يتم الحصول على الكود، انتظر قليلا..', 
            'show_alert'=>true,
            'cache_time'=> 2
        ]);
        $number = $exdata[1];
        $get_code = json_decode(file_get_contents($API_NUMBER.'action=getCode&nmbr='.$number));
                $rate = $value->price;
                $prec_c = $config->Profit;
                $price = ((($rate / 100) * $prec_c) + $rate);
        if($get_code->ok){
            $code = $get_code->data->number->code;
            $pass = $get_code->data->number->password;
            bot('sendmessage', [
                'chat_id' => $chat_id2,
                'text' => "
*✅︙تم وصول الكود بنجاح 🤧🖤.

*📞 ⌯ 𝑵𝑼𝑴𝑩𝑬𝑹* : `$number`
*💬 ⌯ 𝑪𝑶𝑫𝑬 : `$code`

🔥 ⌯ تم خصم $price$ من رصيدك.
                ",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $MyYoussef
                                    ])
            ]);
            

        }else{
            bot('answerCallbackQuery',[
                'callback_query_id'=>$update->callback_query->id,
                'text'=>"🤖︙لم يصل الكود بعد.. انتظر قليلا ثم حاول مجدداً ❌.", 
                'show_alert'=>true,
                'cache_time'=> 10
            ]);
        }

    }


    if($exdata[0] == 'LogOut'){
        $number = $exdata[1];
        $logout = json_decode(file_get_contents($API_NUMBER.'action=logout&nmbr='.$number));
        if($logout->ok){
            bot('answerCallbackQuery',[
                'callback_query_id'=>$update->callback_query->id,
                'text'=>"✅︙تم بنجاح..", 
                'show_alert'=>true,
                'cache_time'=> 10
            ]);
        }else{
            bot('answerCallbackQuery',[
                'callback_query_id'=>$update->callback_query->id,
                'text'=>"❌︙فشل، قد يعود السبب لتسجيل الخروج مسبقا", 
                'show_alert'=>true,
                'cache_time'=> 10
            ]);
        }

    }
    
            if($text && $get_json->data == 'Profit'){
            $json["data"] = null;
            file_put_contents("data/admin.json", json_encode($json));
            $json_config["Profit"] = $text;
            file_put_contents("data/config.json", json_encode($json_config));
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "*✅ ⌯ تم تنفيذ طلبك وتم تعيين نسبة الربح.*",
               'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back2
                                   ])
            ]);
            return;
        }
               if($data == 'Profit'){
            $json["data"] = 'Profit';
            file_put_contents("data/admin.json", json_encode($json));
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*💸︙أرسل نسبة الربح.*",
               'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back2
                                   ])
            ]);
        }
        if($data == 'EngBayahya'){
        bot('editmessagetext', [
            'chat_id' => $chat_id2,
            'message_id' => $message_id2,
            'text' => "
*✅ ⌯ تم تنفيذ طلبك وتم إلغاء العملية بنجاح.*

*🔏 ⌯ للعودة إلى القائمة الرئيسية أضغط زر الرجوع بالأسفل ⬇️.*",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
'inline_keyboard' => $back2
])
]);
}

// تأكد من إدراج ملف الاتصال بقاعدة البيانات
    if ($data == "addhool") {
            $json["data"] = 'addhool';
            file_put_contents("data/admin.json", json_encode($json));
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*⬇️ ⌯ قم بإرسال أسم القسم الان.*",
                'parse_mode' => "MarkDown",
                'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }
        /*
        * إضافة قسم عادي
        */
        if ($data == "addhivi") {
            $json["data"] = 'addhivi';
            file_put_contents("data/admin.json", json_encode($json));
            include('./sql_class.php');
            $but = $sql->sql_readarray('huttons');
            $nerv = [];
            foreach ($but as $hutton) {
                $code = $hutton['code'];
                $name = $hutton['name'];
                $nerv[] = [['text' => $name, 'callback_data' => "codehivi|".$code]];
            }
            $nerv[] = [['text' => "إلغاء ورجوع", 'callback_data' => "back"]];
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*⬇️ ⌯ قم بإختيار القسم الان.*",
                'parse_mode' => "MarkDown",
                'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $nerv
                ])
            ]);
        }
                          
                
                  
                      if ($text and $get_json->data == 'addhool') {
            $json["data"] = 'addhool2';
            $json["name"] = $text;
            file_put_contents("data/admin.json", json_encode($json));
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "
    *☑️ ⌯ تم اضافة القسم ،*
🪗 ⌯ الإسم : *$text*

⬇️ ⌯ أرسل الان *وصف القسم.*
                ",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }
        if ($text and $get_json->data == 'addhool2') {
            $json["data"] = 'addhool3';
            $json["caption"] = $text;
            file_put_contents("data/admin.json", json_encode($json));
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "*✅ ⌯ تم تعيين وصف القسم ،*
🪗 *⌯* الوصف : *$text*

⬇️ ⌯ إضغط */ok* لتأكيد الإضافة ☑️.",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }

        if ($text == '/ok' && $get_json->data == 'addhool3') {
            $code = rand_text();
            include("./sql_class.php");
            $sql = new mysql_api_code($db);
            if (mysqli_connect_errno()) {
                bot('sendMessage', [
                    'chat_id' => $chat_id,
                    'text' =>"Failed to connect to MySQL: " . mysqli_connect_error(),
                    'parse_mode' => "MarkDown",
                    'disable_web_page_preview' => true,
                ]);
                return;
            }
            $name = $get_json->name;
            $api = $get_json->api;
            $caption = $get_json->caption;
            $sql->sql_write('huttons(code,name,caption)', "VALUES('$code','$name','$caption')");
            $json["data"] = null;
            file_put_contents("data/admin.json", json_encode($json));
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "
*✅︙تم تنفيذ طلبك وتم إضافة القسم.*",
'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
            return;
        }
        if ($text == '/ok' && $get_json->data != 'addhool2') {
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "
                *⛔ ⌯ خطأ ،*
*🪗 ⌯ البيانات ليست كافية لإتمام الإضافة.*
                ",
                'parse_mode' => "MarkDown",
            ]);
        }

        /*
        * إضافة قسم عادي
        */
        if ($text and $get_json->data == 'addhivi1') {
            $json["data"] = 'addhivi2';
            $json["name"] = $text;
            file_put_contents("data/admin.json", json_encode($json));
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "
                *☑️ ⌯ تم اضافة القسم ،*
🪗 ⌯ الإسم : *$text*

⬇️ ⌯ أرسل الان *وصف القسم.*
                ",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }

        if ($text and $get_json->data == 'addhivi2') {
            $json["data"] = null;
            file_put_contents("data/admin.json", json_encode($json));
            include("./sql_class.php");
            $sql = new mysql_api_code($db);
            if (mysqli_connect_errno()) {
                bot('sendMessage', [
                    'chat_id' => $chat_id,
                    'text' =>"Failed to connect to MySQL: " . mysqli_connect_error(),
                    'parse_mode' => "MarkDown",
                    'disable_web_page_preview' => true,
                ]);
                return;
            }
            $code = rand_text();
            $name = $get_json->name;
            $codehivi = $get_json->codehivi;
            $caption = $text;
            $sql->sql_write('hivi(code,name,codehivi,caption)', "VALUES('$code','$name', '$codehivi', '$caption')");
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "
                *✅︙تم تنفيذ طلبك وتم إضافة القسم.*
                ",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }


        /*
        * إضافة خدمة
        */
        if ($text and $get_json->data == 'addnerv1') {
            $json["data"] = 'addnerv2';
            $json["name"] = $text;
            file_put_contents("data/admin.json", json_encode($json));
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "
                *☑️ ⌯ إسم الخدمة : $text ،*
*⬇️ ⌯ أرسل الان أيدي الخدمة في الموقع.*
                ",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }
        if ($text and $get_json->data == 'addnerv2') {
            $json["data"] = 'addnerv3';
            $json["num"] = $text;
            file_put_contents("data/admin.json", json_encode($json));
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "*☑️︙أرسل رقم ال API الان.*
*🧿︙1 - 2 - 3 - 4 - 5 - 6 - 7 - 8 - 9 - 10*",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }
        if ($text and $get_json->data == 'addnerv3') {
            $json["data"] = 'addnerv4';
            $json["api"] = $text;
            file_put_contents("data/admin.json", json_encode($json));
            bot('sendMessage', [
            'chat_id' => $chat_id,
                'text' => "
                *🪗︙أرسل الان وصف الخدمة.*
                ",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }
        if ($text and $get_json->data == 'addnerv4') {
            $json["data"] = 'addnerv5';
            $json["caption"] = $text;
            file_put_contents("data/admin.json", json_encode($json));
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "
*💸︙أرسل الان نسبة الربح.*
                ",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }
        if ($text and $get_json->data == 'addnerv5') {
            $json["data"] = null;
            file_put_contents("data/admin.json", json_encode($json));
            include("./sql_class.php");
            $sql = new mysql_api_code($db);
            if (mysqli_connect_errno()) {
                bot('sendMessage', [
                    'chat_id' => $chat_id,
                    'text' =>"Failed to connect to MySQL: " . mysqli_connect_error(),
                    'parse_mode' => "MarkDown",
                    'disable_web_page_preview' => true,
                ]);
                return;
            }
            $codenerv = rand_text();
            $name = $get_json->name;
            $code = $get_json->code;
            $num = $get_json->num;
            $api = $get_json->api;
            $max = $get_json->max;
            $caption = $get_json->caption;
            $precent = $text;
            $sql->sql_write('nerv(code,name,codenerv,num,api,caption,precent)', "VALUES('$code','$name', '$codenerv', '$num', '$api', '$caption','$precent')");
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "
*✅︙تم تنفيذ طلبك وتم إضافة الخدمة بنجاح.*
                ",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }
   
    
    
     if ($exdata[0] == 'codehivi' && $get_json->data == 'addnerv') {
            include('./sql_class.php');
            $but = $sql->sql_select_all('hivi','codehivi', $exdata[1]);
            $nerv = [];
foreach($but as $butt){
                $code = $butt['code'];
                $name = $butt['name'];
                $nerv[] = [['text' => $name, 'callback_data' =>"codenerv|".$code]];
         }
            $nerv[] = [['text' => "إلغاء ورجوع", 'callback_data' => "back"]];
            $json["data"] = 'addnervy';
            file_put_contents("data/admin.json", json_encode($json));
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*⬇️ ⌯ قم بإختيار النوع الان.*",
                'parse_mode' => "MarkDown",
                'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $nerv
                ])
            ]);
        }
        /*
        * اختيار قسم رئيسي لاإضافة قسم عادي
        */
        if($exdata[0] == 'codehivi' && $get_json->data == 'addhivi'){
            $json["data"] = 'addhivi1';
            $json["codehivi"] = $exdata[1];
            file_put_contents("data/admin.json", json_encode($json));
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*☑️ ⌯ تم إختيار القسم الرئيسي ،*
*⬇️ ⌯ قم بأرسال اسم القسم العادي الان.*",'parse_mode' => "MarkDown",
'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }
        /*
        * اختيار قسم لإضافة الخدمة
        */
        if($exdata[0] == 'codenerv' && $get_json->data == 'addnervy'){
            $json["data"] = 'addnerv1';
            $json["code"] = $exdata[1];
            file_put_contents("data/admin.json", json_encode($json));
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*☑️ ⌯ تم إختيار القسم العادي ،*
*⬇️ ⌯ قم بارسال اسم الخدمه الان.*",
                'parse_mode' => "MarkDown",
                'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }
        /*
        * حذف قسم رئيسي
        */
        if ($data == "delhool") {
            include('./sql_class.php');
            $but = $sql->sql_readarray('huttons');
            $nerv = [];
            foreach ($but as $hutton) {
                $code = $hutton['code'];
                $name = $hutton['name'];
                $nerv[] = [['text' => $name, 'callback_data' => "delhoolnerv|".$code]];
            }
            $nerv[] = [['text' => "إلغاء ورجوع", 'callback_data' => "back"]];
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*🪗 ⌯ اختر القسم الرئيسي ليتم حذفه ،*
*⚠️ ⌯ عند حذف قسم رئيسي سيتم حذف جميع الخدمات التي يحتويها.*",
                'parse_mode' => "MarkDown",
                'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $nerv
                ])
            ]);
        }
        if ($exdata[0] == 'delhoolnerv'){
            include('./sql_class.php');
            $sql->sql_del('huttons', 'code', $exdata[1]);
            $s = $sql->sql_select_all('hivi', 'codehivi', $exdata[1]);
            $arr = [];
            foreach($s as $b ){
                $c = $b['code'];
                if(in_array($c, $arr)){
                    continue;
                }
                $sql->sql_del('nerv', 'code', $c);
                $arr [] = $c;
            }
            $sql->sql_del('hivi', 'codehivi', $exdata[1]);
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*✅︙تم تنفيذ طلبك وتم حذف القسم.*",
                'parse_mode' => "MarkDown",
                'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }

        /*
        * حذف قسم عادي
        */
        if ($data == "delhivi") {
            include('./sql_class.php');
            $but = $sql->sql_readarray('hivi');
            $nerv = [];
            foreach ($but as $hutton) {
                $code = $hutton['code'];
                $name = $hutton['name'];
                $nerv[] = [['text' => $name, 'callback_data' => "delhivinerv|".$code]];
            }
            $nerv[] = [['text' => "إلغاء ورجوع", 'callback_data' => "back"]];
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*🪗 ⌯ اختر القسم العادي ليتم حذفه ،*
*⚠️ ⌯ عند حذف قسم سيتم حذف جميع الخدمات التي يحتويها.*",
                'parse_mode' => "MarkDown",
                'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $nerv])
                    ]);
        }
        if ($exdata[0] == 'delhivinerv'){
            include('./sql_class.php');
            $sql->sql_del('hivi', 'code', $exdata[1]);
            $sql->sql_del('nerv', 'code', $exdata[1]);
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*✅︙تم تنفيذ طلبك وتم حذف القسم.*",
                'parse_mode' => "MarkDown",
                'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }
        /*
        * حذف خدمة
        */
        if ($data == 'delnerv'){
            include('./sql_class.php');
            $but = $sql->sql_readarray('hivi');
            $nerv = [];
            foreach ($but as $hutton) {
                $code = $hutton['code'];
                $name = $hutton['name'];
                $nerv[] = [['text' => $name, 'callback_data' => "getnerv|".$code]];
            }
            $nerv[] = [['text' => "إلغاء ورجوع", 'callback_data' => "back"]];
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*⬇️ ⌯ إختر القسم المراد حذف خدمه منه.*",
                'parse_mode' => "MarkDown",
                'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $nerv
                ])
            ]);
        }
        if ($exdata[0] == 'getnerv'){
            include('./sql_class.php');
            $but = $sql->sql_select_all('nerv', 'code', $exdata[1]);
            $nerv = [];
            foreach ($but as $ser) {
                $code = $ser['codenerv'];
                $name = $ser['name'];
                $nerv[] = [['text' => $name, 'callback_data' => "delnervfromhool|".$code]];
            }
            $nerv[] = [['text' => "إلغاء ورجوع", 'callback_data' => "back"]];
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*⬇️ ⌯ إختر الخدمة المراد حذفها.*",
                'parse_mode' => "MarkDown",
                'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $nerv
                ])
            ]);
        }
        if ($exdata[0] == 'delnervfromhool'){
            include('./sql_class.php');
            #$sql->sql_del('buttons', 'code', $exdata[1]);
            $sql->sql_del('nerv', 'codenerv', $exdata[1]);
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*✅︙تم تنفيذ طلبك وتم حذف الخدمة.*",
                'parse_mode' => "MarkDown",
                'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back
                ])
            ]);
        }
                if ($data == "addnerv") {
            include('./sql_class.php');
            $but = $sql->sql_readarray('huttons');
            $nerv = [];
foreach($but as $butt){
                $code = $butt['code'];
                $name = $butt['name'];
                $nerv[] = [['text' => $name, 'callback_data' =>"codehivi|".$code]];
         }
            $nerv[] = [['text' => "إلغاء ورجوع", 'callback_data' => "back"]];
            $json["data"] = 'addnerv';
            file_put_contents("data/admin.json", json_encode($json));
            bot('editmessagetext', [
                'chat_id' => $chat_id2,
                'message_id' => $message_id2,
                'text' => "*⬇️ ⌯ قم بإختيار القسم الان.*",
               'parse_mode' => "MarkDown",
               'disable_web_page_preview' => true,
                'reply_markup' => json_encode([
                    'inline_keyboard' => $nerv
                ])
            ]);
        }
    //***
if ($data == 'nam' && $get_jsons->{$id2}->data == 'nam'){
        $jsons["$id2"] = null;
        file_put_contents("data/data.json", json_encode($jsons));
        $best_users = explode("\n", file_get_contents('data/best_users.txt'));
        $user_one_dollar = explode("\n", file_get_contents('data/user_one_dollar.txt'));
        if(in_array($id2, $user_one_dollar)){
            // bot('answerCallbackQuery',[
//     'callback_query_id'=>$update->callback_query->id,
//     'text'=>"⛔ ⌯ لايمكنك الرشق حالياً ،
// ☑️ ⌯ يجب ان تكون قد قمت بتعبئة رصيدك 0.5$.", 
//     'show_alert'=>true,
//     'cache_time'=> 20,
//     'parse_mode'=>"MarkDown"
// ]);
// return;
        }
        bot('answerCallbackQuery',[
            'callback_query_id'=>$update->callback_query->id,
            'text'=>"✅︙تم تأكيد طلبك ...!", 
            'show_alert'=>false,
            'cache_time'=> 20,
            'parse_mode'=>"MarkDown"
        ]);
        $nerv = $get_jsons->{$id2}->nerv;
        $codenerv = $get_jsons->{$id2}->codenerv;
        $num_order  = $get_jsons->{$id2}->num;
        $price_order = $get_jsons->{$id2}->price_order;
        $price_k = $get_jsons->{$id2}->price_k;
        $link = $get_jsons->{$id2}->link;
        include('./sql_class.php');
        if (mysqli_connect_errno()) {
            bot('sendMessage', [
                'chat_id' => $chat_id2,
                'text' =>"
*🚨 ⌯ حدث خطأ أثناء مراجعة الطلب وتم الالغاء ،*
*♻️ ⌯ حاول مرة أخرى بعد قليل من الوقت.*
                ",
                'parse_mode'=>"MarkDown",
                'disable_web_page_preview' => true,
            ]);
            return;
        }
        $sq = $sql->sql_select('users', 'user', $id2);
        $sq22 = $sql->sql_select('nerv', 'codenerv', $codenerv);
        $apis = $sq22['api'];
        $name = $sq22['name'];
        $num = $sq22['num'];
$code = $sq22['code'];
        $coin = $sq['coin'];
        $spent = $sq['spent'] + $price_order;
        $coin_after = $coin - $price_order;

$serv_aymn = $sql->sql_select('hivi', 'code', $code);
$name_aymn = $serv_aymn['codehivi'];
$AymnTop = $serv_aymn['name'];

$serv_aymna = $sql->sql_select('huttons', 'code', $name_aymn);
$name_aymna = $serv_aymna['name'];

        $sqsq = $sql->sql_select('users', 'user', $id2);
        $mycoin = $sqsq['mycoin'];
        $info_coin = get_coin_info($mycoin);
        $coin_name = $info_coin[1];

        $price_k2 = $price_k * $info_coin[0];
        $price_order2 = $price_order * $info_coin[0];
        $coin2 = $coin * $info_coin[0];
        $coin_after2 = $coin_after * $info_coin[0];
        include_once('apifiles/'.$apis.".php");
        if ($apis == '1'){
            $api = new Api();
        }
        if ($apis == '2'){
            $api = new Api2();
        }
        if ($apis == '3'){
            $api = new Api3();
        }
        if ($apis == '4'){
            $api = new Api4();
        }
       #$api = new Api();
        $balance = json_decode(json_encode($api->balance()))->balance;
        $order = $api->order(array('service' => $num, 'link' => $link, 'quantity' => $num_order));
        $order_js = json_decode(json_encode($order));
        $order_id = $order_js->order;
        if($order_js->error){
            $error = $order->error;
            bot('sendMessage', [
                'chat_id' => $chat_id2,
                'text' =>"*💡 ⌯ حدث خطأ غير متوقع وتم إلغاء الطلب ،*
*♻️ ⌯ تم إرسال إبلاغ للادارة لمعرفة السبب.*",
               'parse_mode' => "MarkDown",
                'disable_web_page_preview' => true,
            ]);
                bot('sendMessage', [
                    'chat_id' => $dev2,
                    'text' =>"*⛔︙خطأ جديد في إحدى الخدمات.*
                    🆔 ⌯ أيدي الخدمة : *$num*
🧿 ⌯ إسم الخدمة : *$name*
🚀 ⌯ الموقع ( API ) : *$apis*
⚠️ ⌯ تقرير الخطأ : *$error*",
                   'parse_mode' => "MarkDown",
                   'disable_web_page_preview' => true,
                ]);
            return;
        }{
        $sql->sql_edit('users', 'coin', $coin_after, 'user', $id2);
        $sql->sql_edit('users', 'spent', $spent, 'user', $id2);

        $mm = $sql->sql_readarray_count('order_waiting') + $sql->sql_readarray_count('order_done');
$Aymmmm = $mm + 1;
$Aymmm  = $mm + 1;
$Aymm  = $mm + 1;
$Aym  = $mm + 1;
        #$order_id = '1000';
bot('editmessagetext', [
            'chat_id' => $chat_id2,
            'message_id'=> $message_id2,
            'text' =>"*✅ ⌯ تم إضافة الطلب بنجاح.*
",
            'parse_mode'=>"MarkDown",
        ]);
        $tlbmo = "*🔔︙عملية شحن جديده*";
$EngAldorafy = strlen($link) - 7;
$EngAymn = substr($link,0,$EngAldorafy);
$EngA = '•••••••';
$EngAymnAldorafi = $EngAymn.$EngA;
$Three = strlen($id2) - 2;
$Aaymn = substr($id2,0,$Three);
$Aaaymn = '••';
$EngAymnnn = $Aaymn.$Aaaymn;
$capYoussef = "

👤 ⌯ العميل : [$first_name](tg://user?id=$id2).
🏆 ⌯ رقم الطلب : *$Aymmmm*
➖➖➖➖➖➖➖➖➖➖
☑️ ⌯ الخدمة : 
*$name*
➖➖➖➖➖➖➖➖➖➖
➕ ⌯ الفئه : *$num_order*
💵 ⌯ السعر : *$price_order2 $coin_name*
➖➖➖➖➖➖➖➖➖➖
🆔 ⌯ ايدي اللاعب : *$link*
";
        $capeta = "

➖➖➖➖➖➖➖➖➖➖
🏆︙رقم الطلب : *$Aymmm*
➕︙الفئه : *$name*
➖➖➖➖➖➖➖➖➖➖
💵︙السعر : *$price_order2 $coin_name*
💲︙السعر بالدولار : *$price_k دولار 🇺🇸.*
➖➖➖➖➖➖➖➖➖➖
🆔︙ايدي اللاعب : *$EngAymnAldorafi*
➖➖➖➖➖➖➖➖➖➖
👤︙العميل : *$EngAymnnn*
";
$capeta2 = "

➖➖➖➖➖➖➖➖➖➖
🆔 ⌯ ايدي الطلب : *$Aymm*
➕ ⌯ الفئه : *$name*
➖➖➖➖➖➖➖➖➖➖
💵 ⌯ تم خصم : *$price_order2 $coin_name*
💰 ⌯ رصيدك قبل الطلب : *$coin2 $coin_name*
♻️ ⌯ رصيدك بعد الطلب  : *$coin_after2 $coin_name*
➖➖➖➖➖➖➖➖➖➖
🆔 ⌯️ ايدي اللاعب : *$link*
";
        $cap_for_admins = "
*✅︙عملية شحن جديدة.*

👤 ⌯ العضو : [$first_name](tg://user?id=$id2).
🧿 ⌯ إسم الخدمة : *$name*
🪗 ⌯ كود الخدمة : *$codenerv*
🆔 ⌯ أيدي الطلب : *$Aym*

💸 ⌯ سعر الطلب : *$price_order$*
💸 ⌯ سعر الطلب : *$price_order2 $coin_name*

🆔 ⌯ أيدي الخدمة : *$num*

💲 ⌯ رصيد العضو قبل الطلب : *$coin$*
💲 ⌯ رصيد العضو قبل الطلب : *$coin2 $coin_name*

☑️ ⌯ رصيد العضو بعد الطلب : *$coin_after$*
☑️ ⌯ رصيد العضو بعد الطلب : *$coin_after2 $coin_name*

💎 ⌯ - رصيدك بموقع *$apis : $balance$*
🔗 ⌯ ايدي اللاعب : *$link*
";
        $stut = '*📢︙حالة الطلب : جارِ التنفيذ... ☑️.*';
        $sql->sql_write('order_waiting(user,caption,ms_user,ms_channel,order_id,api,price,num_order,link)', "VALUES('$id2','$capYoussef','$f_user', '$f_chat','$order_id','$apis','$price_order','1000','$link')");
bot('sendMessage', [
            'chat_id' => $chat_id2,
            'text' => $tlbmo.$capeta2,
            'parse_mode'=>"MarkDown",
            'disable_web_page_preview' => true,
        ]);
        $f_user = $for_user->result->message_id;
   bot('sendMessage', [
            'chat_id' => $IDCH,
            'text' => $tlbmo.$capeta,
            'parse_mode'=>'MarkDown',
            'disable_web_page_preview' => true,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
[['text'=>"✅ ⌯ الطلب من نفس خدمة الشحن.",'callback_data'=>"EngAymn7dmhd|".$num."|".$codenerv]],
]
            ])
        ]);
        $f_chat = $for_chat->result->message_id;
            bot('sendMessage', [
                'chat_id' => $dev2,
                'text' => $cap_for_admins."".$stut,
                'parse_mode'=>"MarkDown",
                'disable_web_page_preview' => true,
            ]);
        }}
        if($exdata[0] == 'EngAymn7dmhd'){
        $jsons["$id2"]["data"] = 'link';
        $jsons["$id2"]["nerv"] = $exdata[1];
        $jsons["$id2"]["codenerv"] = $exdata[2];
        file_put_contents("data/data.json", json_encode($jsons));
        include('./sql_class.php');
        $sq = $sql->sql_select('nerv', 'codenerv', $exdata[2]);
        $cap = $sq['caption'];
        $prec_c = $sq['precent'];
        $num = $sq['num'];
        $apis = $sq['api'];

        $sqsq = $sql->sql_select('users', 'user', $id2);
        $mycoin = $sqsq['mycoin'];
        $info_coin = get_coin_info($mycoin);
        $coin_name = $info_coin[1];

        $g = get_serv($apis, $num);
        $rate = $g['rate'];
        #$sq = $sql->sql_select('serv', 'codeserv', $code);
        $price = ((($rate / 100) * $prec_c) + $rate) * $info_coin[0];
        $min = shortNumber($g['min']);
        $max = shortNumber($g['max']);
        $ms = "💰 ⌯ السعر : *$price $coin_name*

*🔱︙قم الان بإرسال ايدي اللاعب.*
        ";
        bot('sendMessage', [
            'chat_id' => $id2,
            'text' => $cap."\n".$ms,
            'parse_mode' => "MarkDown",
            'disable_web_page_preview' => true,
            'reply_markup' => json_encode([
                'inline_keyboard' => $back_add
            ])
        ]);
        bot('answerCallbackQuery',[
            'callback_query_id'=>$update->callback_query->id,
            'text'=>"🚀 ⌯ قام البوت بتجهيز الخدمة لكِ...
🔃 ⌯ ادخل الى البوت للتفقد", 
            'show_alert'=>true,
            'cache_time'=> 20
        ]);
    }
    if ($data == 'nam' && $get_jsons->{$id2}->data != 'nam'){
        bot('answerCallbackQuery',[
            'callback_query_id'=>$update->callback_query->id,
            'text'=>"😔 ⌯ لايتوفر خدمات في هذا القسم ،
🪗 ⌯ قم بتجربه قسم آخر او عد مجدداً بعد دقائق.", 
            'show_alert'=>true,
            'cache_time'=> 20
        ]);
        return;
    }
   #--------+-+------++_+-_--_-_-_-_-_----
    
     
      
       
        
          if($data == 'addplay'){
        $jsons["$id2"] = null;
        file_put_contents("data/data.json", json_encode($jsons));
        include('./sql_class.php');
        $but = $sql->sql_readarray('huttons');
        $nerv = [];
        foreach ($but as $hutton) {
            $code = $hutton['code'];
            $name = $hutton['name'];
$Aymn = $hutton['caption'];
            $nerv[] = [['text' => $name, 'callback_data' => "selcethivi|".$code]];
        }
        $nerv[] = [['text' => "🔙︙رجوع.", 'callback_data' => "back2"]];
        bot('editmessagetext', [
            'chat_id' => $chat_id2,
            'message_id' => $message_id2,
            'text' => "*إشحن العابك وتطبيقاتك من هنا 🙋🏻‍♂.*

*🤖︙إختر القسم التي تريد الشحن منه في الأسفل*",
            'parse_mode' => "MarkDown",
            'disable_web_page_preview' => true,
            'reply_markup' => json_encode([
                'inline_keyboard' => $nerv
            ])
        ]);
    }
    if($exdata[0] == 'selcethivi'){
        include('./sql_class.php');
        $but = $sql->sql_select_all('hivi', 'codehivi', $exdata[1]);
        $EngAldorafy = $sql->sql_readarray('huttons');
        $nerv = [];
foreach ($EngAldorafy as $ENGAymn) {
            $Aymn = $ENGAymn['caption'];
}
        foreach ($but as $hutton) {
            $code = $hutton['code'];
            $name = $hutton['name'];
            $nerv[] = [['text' => $name, 'callback_data' => "selecthool|".$code]];
        }
        $nerv[] = [['text' => "🔙 ⌯ رجوع.", 'callback_data' => "addplay"]];
        bot('editmessagetext', [
            'chat_id' => $chat_id2,
            'message_id' => $message_id2,
            'text' => "*🏆︙تم اختيار القسم بنجاح *

*🔃︙اختر الان اللعبه الذي تريد شحنها..!*",
            'parse_mode' => "MarkDown",
            'disable_web_page_preview' => true,
            'reply_markup' => json_encode([
                'inline_keyboard' => $nerv
            ])
        ]);
    }
    if ($exdata[0] == 'selecthool'){
$Aaa = rand(1,4);
$Yyy = strlen($Aaa) + 1;
$hhhhhhh ='';
for($i=0;$i<$Yyy;$i++){
$hhhhhhh .= '.';
}
$myaymn = $hhhhhhh;
        bot('editmessagetext',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
            'text'=>"*🔱︙جاري تحميل الفئات*".$myaymn, 
'parse_mode'=>"MarkDown",
        ]);
        include('./sql_class.php');
        $but = $sql->sql_select_all('nerv', 'code', $exdata[1]);
        $qq = $sql->sql_select('hivi', 'code', $exdata[1]);

        $sq = $sql->sql_select('users', 'user', $id2);
        $mycoin = $sq['mycoin'];
        $info_coin = get_coin_info($mycoin);
        $coin_name = $info_coin[1];

        $cap = $qq['caption'];
        #return;
        $nerv = [];
        $nerv[] = [['text' => "🎮︙الفئة", 'callback_data' => "no"],['text' => "💸︙السعر", 'callback_data' => "no"]];
        foreach ($but as $ser) {
            $code = $ser['codenerv'];
            $name = $ser['name'];
            $num = $ser['num'];
            $apis = $ser['api'];
            $prec_c = $ser['precent'];
            $g = get_serv($apis, $num);
            if(!$g){
                continue;
            }
            $rate = $g['rate'];
            #$sq = $sql->sql_select('serv', 'codeserv', $code);
            $price = ((($rate / 100) * $prec_c) + $rate) * $info_coin[0];
            $min = $g['min'];
            $max = $g['max'];
            $nerv[] = [['text' => $name, 'callback_data' => "selcetnerv|".$num."|".$code],['text' => $price.$coin_name, 'callback_data' => "selcetnerv|".$num."|".$code]];
            $g = '';
        }
        $nerv[] = [['text' => "🔙 ⌯ رجوع.", 'callback_data' => "addplay"]];
        bot('editmessagetext', [
            'chat_id' => $chat_id2,
            'message_id' => $message_id2,
            'text' => $cap,
            'parse_mode' => "MarkDown",
            'disable_web_page_preview' => true,
            'reply_markup' => json_encode([
                'inline_keyboard' => $nerv
            ])
        ]);
        #file_put_contents('t.txt', 'sss', FILE_APPEND);

    }
if($exdata[0] == 'selcetnerv'){
        $jsons["$id2"]["data"] = 'hink';
        $jsons["$id2"]["nerv"] = $exdata[1];
        $jsons["$id2"]["codenerv"] = $exdata[2];
        file_put_contents("data/data.json", json_encode($jsons));
        include('./sql_class.php');
        $sq = $sql->sql_select('nerv', 'codenerv', $exdata[2]);
        $cap = $sq['caption'];
        $prec_c = $sq['precent'];
        $num = $sq['num'];
        $apis = $sq['api'];

        $sqsq = $sql->sql_select('users', 'user', $id2);
        $mycoin = $sqsq['mycoin'];
        $info_coin = get_coin_info($mycoin);
        $coin_name = $info_coin[1];
        
        $g = get_serv($apis, $num);
        $rate = $g['rate'];
        #$sq = $sql->sql_select('serv', 'codeserv', $code);
        $price = ((($rate / 100) * $prec_c) + $rate) * $info_coin[0];
                    $name = $ser['name'];
        $min = shortNumber($g['min']);
        $max = shortNumber($g['max']);
        $ms = "
🎮︙الخدمة : *$name*
💲︙السعر : *$price $coin_name*
🔗︙الحقول المطلوبة : *ايدي اللاعب*

*✅ ⌯ يرجى إرسال الحقول المطلوبة كما هو موضح بالأعلى ☝🏻.*
        ";
        bot('editmessagetext', [
            'chat_id' => $chat_id2,
            'message_id' => $message_id2,
            'text' => $cap."\n".$ms,
            'parse_mode' => "MarkDown",
            'disable_web_page_preview' => true,
            'reply_markup' => json_encode([
                'inline_keyboard' => $back_add
            ])
        ]);
     }
    

  
    
        
        if($text && $get_jsons->{$id}->data == 'hink'){

include('./sql_class.php');
        $sq = $sql->sql_select('users', 'user', $id);
        $coin = $sq['coin'];
        $nerv = $get_jsons->{$id}->nerv;
        $codenerv = $get_jsons->{$id}->codenerv;
        $sq22 = $sql->sql_select('nerv', 'codenerv', $codenerv);
        $api = $sq22['api'];
        $name = $sq22['name'];
        $num = $sq22['num'];
        $prec = $sq22['precent'];
        $g = get_serv($api, $nerv);
                     $sqsq = $sql->sql_select('users', 'user', $id);
        $mycoin = $sqsq['mycoin'];
        $info_coin = get_coin_info($mycoin);
        $coin_name = $info_coin[1];
        
                       $sqsq = $sql->sql_select('users', 'user', $id);
        $mycoin = $sqsq['mycoin'];
        $info_coin = get_coin_info($mycoin);
        $coin_name = $info_coin[1];
        

       
        $sq = $sql->sql_select('nerv', 'codenerv', $exdata[2]);
        $cap = $sq['caption'];
        $prec_c = $sq['precent'];
        $num = $sq['num'];
        $apis = $sq['api'];

        $sqsq = $sql->sql_select('users', 'user', $id2);
        $mycoin = $sqsq['mycoin'];
        $info_coin = get_coin_info($mycoin);
        $coin_name = $info_coin[1];
        

            $jsons["$id"] = null;
            file_put_contents("data/data.json", json_encode($jsons));
                if($coin < $price_order){
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "*⛔ ⌯ رصيدك غير كافي لهذا العدد ،*
*☑️ ⌯ قم بإعادة شحن حسابك أو اطلب عدد اقل* ",
              'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => $back_add
                ])
            ]);
            return;
        }
                $sqsq = $sql->sql_select('users', 'user', $id);
        $mycoin = $sqsq['mycoin'];
        $info_coin = get_coin_info($mycoin);
        $coin_name = $info_coin[1];
        


$PriceCoin = $price * $infoCoin[0];
     $coin_after = $coin - $price;
        $spent_after = $spent + $price;
        $sql->sql_edit('users', 'coin', $coin_after, 'user', $id2);
        
         $jsons["$id"]["data"] = 'nam';
        $jsons["$id"]["link"] = $text;
        $jsons["$id"]["api"] = $api;
        $jsons["$id"]["price_order"] = $price_order;
        $jsons["$id"]["price_k"] = $price;
       bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "🎮 ⌯ الفئه : *$name*
💰 ⌯ السعر  : *$price $coin_name*
👤 ⌯ ايدي اللاعب : *$text*
💳 ⌯ رصيدك الحالي : *$coin $coin_name*
☑️ ⌯ رصيدك بعد الطلب : *$coin_after $coin_name*

*✅ - هل تريد تأكيد عملية الشحن ؟*",
          'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => $nam
            ])
        ]);
        return;
    }
    include ('Youssef.php');
?>